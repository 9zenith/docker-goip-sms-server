<?php
	if(function_exists('mb_strlen1')) echo "1";
?>
